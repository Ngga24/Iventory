const Inventory = require('../models/inventoryModel');

exports.getItems = (req, res) => {
  Inventory.getAll((err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results);
  });
};

exports.getItemById = (req, res) => {
  Inventory.getById(req.params.id, (err, results) => {
    if (err) return res.status(500).json(err);
    res.json(results[0]);
  });
};

exports.createItem = (req, res) => {
  Inventory.create(req.body, (err, result) => {
    if (err) return res.status(500).json(err);
    res.json({ id: result.insertId, ...req.body });
  });
};

exports.updateItem = (req, res) => {
  Inventory.update(req.params.id, req.body, (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Item updated' });
  });
};

exports.deleteItem = (req, res) => {
  Inventory.delete(req.params.id, (err) => {
    if (err) return res.status(500).json(err);
    res.json({ message: 'Item deleted' });
  });
};
