const db = require('../config/db');

const Inventory = {
  getAll: (cb) => db.query("SELECT * FROM items", cb),

  getById: (id, cb) => db.query("SELECT * FROM items WHERE id = ?", [id], cb),

  create: (data, cb) =>
    db.query("INSERT INTO items (name, description, quantity, category) VALUES (?, ?, ?, ?)", 
      [data.name, data.description, data.quantity, data.category], cb),

  update: (id, data, cb) =>
    db.query("UPDATE items SET name=?, description=?, quantity=?, category=? WHERE id=?",
      [data.name, data.description, data.quantity, data.category, id], cb),

  delete: (id, cb) => db.query("DELETE FROM items WHERE id = ?", [id], cb)
};

module.exports = Inventory;
